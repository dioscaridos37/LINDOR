#!/bin/bash
set -e

echo "======================================"
echo "  LINDOR Browser — build script"
echo "======================================"

# Check for Java
if ! command -v java &> /dev/null; then
    echo "Error: Java not found. Install JDK 17+"
    exit 1
fi

# Use gradle wrapper if present, otherwise try system gradle
if [ -f "./gradlew" ]; then
    GRADLE="./gradlew"
    chmod +x ./gradlew
else
    if command -v gradle &> /dev/null; then
        GRADLE="gradle"
    else
        echo "No gradlew and no system gradle found."
        echo "Downloading Gradle wrapper..."
        # Minimal bootstrap
        GRADLE_VERSION=8.9
        curl -sL "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o /tmp/gradle.zip
        unzip -q /tmp/gradle.zip -d /tmp
        export PATH="/tmp/gradle-${GRADLE_VERSION}/bin:$PATH"
        GRADLE="gradle"
        # Generate wrapper
        gradle wrapper --gradle-version ${GRADLE_VERSION}
        GRADLE="./gradlew"
        chmod +x ./gradlew
    fi
fi

echo "→ Cleaning..."
$GRADLE clean --quiet

echo "→ Assembling debug APK..."
$GRADLE assembleDebug --quiet

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo ""
    echo "✅ Build successful!"
    echo "APK: $APK"
    ls -lh "$APK"
else
    echo "❌ APK not found. Check build logs."
    exit 1
fi
