# LINDOR Browser

Лёгкий и приятный Android-браузер в стиле **OriginOS Liquid Glass**.

- Полупрозрачные glass-панели
- Пружинные (spring) анимации
- Плавные появления / исчезновения
- Аккуратная навигация и вкладки
- Без лишней перегрузки

## Возможности

- WebView с JavaScript, zoom, DOM storage
- Адресная строка с поиском Google
- Вкладки (создание / закрытие / переключение)
- Назад / Вперёд / Домой / Обновить
- Прогресс-бар загрузки
- Edge-to-edge, поддержка тёмной темы
- Плавные spring-анимации кнопок и оверлеев

## Сборка

### Требования
- Android Studio Ladybug+ или JDK 17
- Android SDK 35

### Быстрая сборка (из корня репозитория)

```bash
chmod +x build.sh
./build.sh
```

Скрипт соберёт debug APK:

```
app/build/outputs/apk/debug/app-debug.apk
```

### Вручную

```bash
./gradlew assembleDebug
# или release
./gradlew assembleRelease
```

## Структура

```
LINDOR/
├── app/
│   └── src/main/java/com/lindor/browser/
│       ├── MainActivity.kt
│       ├── BrowserViewModel.kt
│       ├── data/Tab.kt
│       └── ui/
│           ├── theme/
│           ├── components/   (Glass + WebView)
│           └── screens/      (BrowserScreen)
├── build.sh
└── README.md
```

## Дизайн

Вдохновлён OriginOS 6/7 Liquid Glass:
- Полупрозрачные поверхности с мягким градиентом и тонкой рамкой
- Spring damping для нажатий
- Плавные fade + slide для оверлеев вкладок и меню
- Минималистичная нижняя панель в виде стеклянной «пилюли»

Сделано аккуратно, без тяжёлых эффектов, чтобы работало плавно даже на средних устройствах.
