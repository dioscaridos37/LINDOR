package com.lindor.browser.data

import java.util.UUID

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    var url: String = "about:blank",
    var title: String = "New Tab",
    var isLoading: Boolean = false,
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    var progress: Float = 0f
)
