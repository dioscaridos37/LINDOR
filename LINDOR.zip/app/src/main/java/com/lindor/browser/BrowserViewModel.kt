package com.lindor.browser

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.lindor.browser.data.BrowserTab

class BrowserViewModel : ViewModel() {
    val tabs = mutableStateListOf(
        BrowserTab(url = HOME_URL, title = "Home")
    )
    val currentTabIndex = mutableStateOf(0)
    val showTabsOverlay = mutableStateOf(false)
    val showMenu = mutableStateOf(false)
    val addressBarFocused = mutableStateOf(false)
    val addressText = mutableStateOf("")

    val currentTab: BrowserTab
        get() = tabs.getOrElse(currentTabIndex.value) { tabs.first() }

    fun newTab(url: String = HOME_URL) {
        val tab = BrowserTab(url = url, title = if (url == HOME_URL) "Home" else "New Tab")
        tabs.add(tab)
        currentTabIndex.value = tabs.lastIndex
        addressText.value = if (url == HOME_URL) "" else url
        showTabsOverlay.value = false
    }

    fun closeTab(index: Int) {
        if (tabs.size <= 1) {
            // Reset the last tab
            tabs[0] = BrowserTab(url = HOME_URL, title = "Home")
            currentTabIndex.value = 0
            addressText.value = ""
            return
        }
        tabs.removeAt(index)
        if (currentTabIndex.value >= tabs.size) {
            currentTabIndex.value = tabs.lastIndex
        } else if (currentTabIndex.value > index) {
            currentTabIndex.value -= 1
        }
        addressText.value = currentTab.url.takeIf { it != HOME_URL && it != "about:blank" } ?: ""
    }

    fun selectTab(index: Int) {
        if (index in tabs.indices) {
            currentTabIndex.value = index
            addressText.value = currentTab.url.takeIf { it != HOME_URL && it != "about:blank" } ?: ""
            showTabsOverlay.value = false
        }
    }

    fun updateCurrentTab(
        url: String? = null,
        title: String? = null,
        isLoading: Boolean? = null,
        canGoBack: Boolean? = null,
        canGoForward: Boolean? = null,
        progress: Float? = null
    ) {
        val idx = currentTabIndex.value
        if (idx !in tabs.indices) return
        val tab = tabs[idx]
        tabs[idx] = tab.copy(
            url = url ?: tab.url,
            title = title ?: tab.title,
            isLoading = isLoading ?: tab.isLoading,
            canGoBack = canGoBack ?: tab.canGoBack,
            canGoForward = canGoForward ?: tab.canGoForward,
            progress = progress ?: tab.progress
        )
        if (url != null && !addressBarFocused.value) {
            addressText.value = if (url == HOME_URL || url == "about:blank") "" else url
        }
    }

    companion object {
        const val HOME_URL = "https://www.google.com"
    }
}
