package com.lindor.browser.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    secondary = AccentBlueSoft,
    onSecondary = Color.White,
    background = SurfaceLight,
    onBackground = TextPrimaryLight,
    surface = GlassWhite,
    onSurface = TextPrimaryLight,
    surfaceVariant = GlassWhiteSoft,
    onSurfaceVariant = TextSecondaryLight,
    outline = DividerLight
)

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlueSoft,
    onPrimary = Color.Black,
    secondary = AccentPurple,
    onSecondary = Color.White,
    background = SurfaceDark,
    onBackground = TextPrimaryDark,
    surface = GlassDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = GlassDarkSoft,
    onSurfaceVariant = TextSecondaryDark,
    outline = DividerDark
)

@Composable
fun LINDORTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
