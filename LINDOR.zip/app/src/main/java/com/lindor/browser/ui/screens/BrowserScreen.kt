package com.lindor.browser.ui.screens

import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tab
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lindor.browser.BrowserViewModel
import com.lindor.browser.ui.components.BrowserWebView
import com.lindor.browser.ui.components.GlassIconButton
import com.lindor.browser.ui.components.GlassPill
import com.lindor.browser.ui.components.GlassSurface
import com.lindor.browser.ui.theme.AccentBlue
import com.lindor.browser.ui.theme.ProgressBlue

@Composable
fun BrowserScreen(viewModel: BrowserViewModel) {
    val isDark = isSystemInDarkTheme()
    val currentTab = viewModel.currentTab
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }

    // System back → WebView history first
    BackHandler(enabled = currentTab.canGoBack) {
        webViewRef?.goBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = if (isDark) {
                        listOf(Color(0xFF0D0D12), Color(0xFF1A1A22))
                    } else {
                        listOf(Color(0xFFF5F7FA), Color(0xFFE8ECF2))
                    }
                )
            )
    ) {
        // Web content
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(Modifier.statusBarsPadding().height(64.dp)) // space for top bar

            Box(modifier = Modifier.weight(1f)) {
                BrowserWebView(
                    url = currentTab.url,
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize(),
                    onWebViewCreated = { webViewRef = it }
                )

                // Progress bar (liquid fade)
                AnimatedVisibility(
                    visible = currentTab.isLoading && currentTab.progress < 1f,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.TopCenter)
                ) {
                    LinearProgressIndicator(
                        progress = currentTab.progress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.5.dp),
                        color = ProgressBlue,
                        trackColor = Color.Transparent
                    )
                }
            }

            // Bottom glass navigation
            BottomBar(
                isDark = isDark,
                canGoBack = currentTab.canGoBack,
                canGoForward = currentTab.canGoForward,
                tabCount = viewModel.tabs.size,
                onBack = { webViewRef?.goBack() },
                onForward = { webViewRef?.goForward() },
                onHome = {
                    viewModel.updateCurrentTab(url = BrowserViewModel.HOME_URL, title = "Home")
                    webViewRef?.loadUrl(BrowserViewModel.HOME_URL)
                    viewModel.addressText.value = ""
                },
                onTabs = { viewModel.showTabsOverlay.value = true },
                onMenu = { viewModel.showMenu.value = !viewModel.showMenu.value },
                onRefresh = { webViewRef?.reload() }
            )
        }

        // Top address bar (floating glass)
        TopAddressBar(
            isDark = isDark,
            addressText = viewModel.addressText.value,
            onAddressChange = { viewModel.addressText.value = it },
            isFocused = viewModel.addressBarFocused.value,
            onFocusChange = { viewModel.addressBarFocused.value = it },
            focusRequester = focusRequester,
            onSubmit = {
                val raw = viewModel.addressText.value.trim()
                if (raw.isEmpty()) return@TopAddressBar
                val target = when {
                    raw.startsWith("http://") || raw.startsWith("https://") -> raw
                    raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                    else -> "https://www.google.com/search?q=${java.net.URLEncoder.encode(raw, "UTF-8")}"
                }
                viewModel.updateCurrentTab(url = target, isLoading = true)
                webViewRef?.loadUrl(target)
                viewModel.addressBarFocused.value = false
                focusManager.clearFocus()
                keyboardController?.hide()
            },
            onClear = {
                viewModel.addressText.value = ""
                focusRequester.requestFocus()
            }
        )

        // Tabs overlay
        AnimatedVisibility(
            visible = viewModel.showTabsOverlay.value,
            enter = fadeIn() + slideInVertically(
                initialOffsetY = { it / 3 },
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
            ),
            exit = fadeOut() + slideOutVertically(
                targetOffsetY = { it / 3 },
                animationSpec = spring(stiffness = Spring.StiffnessMedium)
            )
        ) {
            TabsOverlay(
                isDark = isDark,
                tabs = viewModel.tabs,
                currentIndex = viewModel.currentTabIndex.value,
                onSelect = { viewModel.selectTab(it) },
                onClose = { viewModel.closeTab(it) },
                onNewTab = { viewModel.newTab() },
                onDismiss = { viewModel.showTabsOverlay.value = false }
            )
        }

        // Simple menu
        AnimatedVisibility(
            visible = viewModel.showMenu.value,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 4 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 4 })
        ) {
            MenuOverlay(
                isDark = isDark,
                onDismiss = { viewModel.showMenu.value = false },
                onNewTab = {
                    viewModel.newTab()
                    viewModel.showMenu.value = false
                },
                onRefresh = {
                    webViewRef?.reload()
                    viewModel.showMenu.value = false
                }
            )
        }
    }
}

@Composable
private fun TopAddressBar(
    isDark: Boolean,
    addressText: String,
    onAddressChange: (String) -> Unit,
    isFocused: Boolean,
    onFocusChange: (Boolean) -> Unit,
    focusRequester: FocusRequester,
    onSubmit: () -> Unit,
    onClear: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        GlassPill(
            modifier = Modifier.fillMaxWidth(),
            isDark = isDark
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Home,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = addressText,
                    onValueChange = onAddressChange,
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                        .onFocusChanged { onFocusChange(it.isFocused) },
                    textStyle = TextStyle(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 15.sp
                    ),
                    singleLine = true,
                    cursorBrush = SolidColor(AccentBlue),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                    decorationBox = { inner ->
                        Box {
                            if (addressText.isEmpty()) {
                                Text(
                                    text = "Search or enter URL",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    fontSize = 15.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                if (addressText.isNotEmpty()) {
                    GlassIconButton(
                        onClick = onClear,
                        size = 32.dp
                    ) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(
    isDark: Boolean,
    canGoBack: Boolean,
    canGoForward: Boolean,
    tabCount: Int,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    onMenu: () -> Unit,
    onRefresh: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            isDark = isDark,
            elevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavIcon(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    enabled = canGoBack,
                    onClick = onBack
                )
                NavIcon(
                    icon = Icons.AutoMirrored.Rounded.ArrowForward,
                    enabled = canGoForward,
                    onClick = onForward
                )
                NavIcon(
                    icon = Icons.Rounded.Home,
                    onClick = onHome
                )
                // Tabs with badge
                Box {
                    NavIcon(
                        icon = Icons.Rounded.Tab,
                        onClick = onTabs
                    )
                    if (tabCount > 1) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 6.dp, end = 6.dp)
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(AccentBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (tabCount > 9) "9+" else tabCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
                NavIcon(
                    icon = Icons.Rounded.MoreVert,
                    onClick = onMenu
                )
            }
        }
    }
}

@Composable
private fun NavIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val alpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.35f,
        animationSpec = spring(),
        label = "navAlpha"
    )
    GlassIconButton(
        onClick = onClick,
        enabled = enabled,
        size = 48.dp
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha),
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun TabsOverlay(
    isDark: Boolean,
    tabs: List<com.lindor.browser.data.BrowserTab>,
    currentIndex: Int,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNewTab: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(onClick = onDismiss)
    ) {
        GlassSurface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .navigationBarsPadding(),
            shape = RoundedCornerShape(28.dp),
            isDark = isDark,
            elevation = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tabs",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    GlassIconButton(onClick = onNewTab, size = 40.dp) {
                        Icon(
                            Icons.Rounded.Add,
                            contentDescription = "New Tab",
                            tint = AccentBlue
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(280.dp)
                ) {
                    itemsIndexed(tabs) { index, tab ->
                        TabCard(
                            title = tab.title,
                            url = tab.url,
                            isSelected = index == currentIndex,
                            isDark = isDark,
                            onClick = { onSelect(index) },
                            onClose = { onClose(index) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabCard(
    title: String,
    url: String,
    isSelected: Boolean,
    isDark: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.02f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "tabScale"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isSelected) AccentBlue.copy(alpha = 0.15f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title.ifBlank { "New Tab" },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = url.takeIf { it != "about:blank" && it.isNotBlank() } ?: "Home",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            GlassIconButton(onClick = onClose, size = 32.dp) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun MenuOverlay(
    isDark: Boolean,
    onDismiss: () -> Unit,
    onNewTab: () -> Unit,
    onRefresh: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .clickable(onClick = onDismiss)
    ) {
        GlassSurface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 90.dp)
                .width(200.dp),
            shape = RoundedCornerShape(20.dp),
            isDark = isDark,
            elevation = 16.dp
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                MenuItem(text = "New Tab", onClick = onNewTab)
                MenuItem(text = "Refresh", onClick = onRefresh)
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
                MenuItem(text = "About LINDOR", onClick = onDismiss)
            }
        }
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    )
}
