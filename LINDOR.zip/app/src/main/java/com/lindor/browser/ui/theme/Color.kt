package com.lindor.browser.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid Glass palette inspired by OriginOS
val GlassWhite = Color(0xE6FFFFFF)
val GlassWhiteSoft = Color(0xB3FFFFFF)
val GlassDark = Color(0xE6121212)
val GlassDarkSoft = Color(0xB3121212)

val AccentBlue = Color(0xFF0A84FF)
val AccentBlueSoft = Color(0xFF5AC8FA)
val AccentPurple = Color(0xFFBF5AF2)

val SurfaceLight = Color(0xFFF2F2F7)
val SurfaceDark = Color(0xFF1C1C1E)

val TextPrimaryLight = Color(0xFF1C1C1E)
val TextPrimaryDark = Color(0xFFF2F2F7)
val TextSecondaryLight = Color(0xFF8E8E93)
val TextSecondaryDark = Color(0xFF8E8E93)

val ProgressBlue = Color(0xFF0A84FF)
val DividerLight = Color(0x1A000000)
val DividerDark = Color(0x1AFFFFFF)
