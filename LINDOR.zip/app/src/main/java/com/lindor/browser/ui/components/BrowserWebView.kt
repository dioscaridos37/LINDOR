package com.lindor.browser.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.lindor.browser.BrowserViewModel

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserWebView(
    url: String,
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier,
    onWebViewCreated: (WebView) -> Unit = {}
) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = true
                displayZoomControls = false
                setSupportZoom(true)
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = userAgentString.replace("; wv", "")
                mediaPlaybackRequiresUserGesture = false
            }
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(0)
        }
    }

    DisposableEffect(Unit) {
        onWebViewCreated(webView)
        onDispose {
            // Keep WebView alive across recompositions; clean only on real dispose if needed
        }
    }

    AndroidView(
        factory = { webView },
        modifier = modifier,
        update = { view ->
            view.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val target = request?.url?.toString() ?: return false
                    if (target.startsWith("http://") || target.startsWith("https://")) {
                        return false
                    }
                    return true
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    viewModel.updateCurrentTab(
                        url = url,
                        isLoading = true,
                        progress = 0.05f
                    )
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    viewModel.updateCurrentTab(
                        url = url,
                        title = view?.title ?: "Untitled",
                        isLoading = false,
                        canGoBack = view?.canGoBack() == true,
                        canGoForward = view?.canGoForward() == true,
                        progress = 1f
                    )
                }
            }

            view.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    viewModel.updateCurrentTab(progress = newProgress / 100f)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    viewModel.updateCurrentTab(title = title ?: "Untitled")
                }
            }

            // Load only if different to avoid reload loops
            val current = view.url
            if (current == null || (url.isNotBlank() && current != url && url != "about:blank")) {
                if (url == BrowserViewModel.HOME_URL || url.startsWith("http")) {
                    view.loadUrl(url)
                }
            }
        }
    )
}
